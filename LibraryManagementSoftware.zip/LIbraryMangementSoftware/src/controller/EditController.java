package controller;

import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.util.List;
import model.BookLibrary;
import service.BookLibraryImpl;
import service.BookLibraryInterface;

/**
 * Servlet implementation class EditController
 */
@WebServlet("/EditController")

public class EditController extends HttpServlet {
	
	private BookLibraryInterface bookLib=new BookLibraryImpl();
	
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EditController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
       
					
	}
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		
		//System.out.println("post block editcontroller ");

	

		Integer eId=Integer.parseInt(request.getParameter("eId"));
		String bookname=request.getParameter("bookname");
		String title=request.getParameter("title");
		String author=request.getParameter("author");
		String publishername=request.getParameter("publishername");
		String copyright=request.getParameter("copyright");
		String edition=request.getParameter("edition");
		Integer pages=Integer.parseInt(request.getParameter("pages"));
		Double isbn=Double.parseDouble(request.getParameter("isbn"));
		Integer copies=Integer.parseInt(request.getParameter("copies"));	
		String libraryname=request.getParameter("libraryname");
		Integer shelfnum=Integer.parseInt(request.getParameter("shelfnum"));
		
		BookLibrary booklib=new BookLibrary();
		
		booklib.setId(eId);
		booklib.setBookname(bookname);
		booklib.setTitle(title);
		booklib.setAuthor(author);
		booklib.setPublishername(publishername);
		booklib.setCopies(copies);
		booklib.setEdition(edition);
		booklib.setPages(pages);
		booklib.setIsbn(isbn);
		booklib.setLibraryname(libraryname);
		booklib.setShelfnum(shelfnum);
		bookLib.editInfo(booklib);
		
		List<BookLibrary> list=bookLib.getAllInfo();
		request.setAttribute("libInformationlist",list);
				
				
       RequestDispatcher rd=request.getRequestDispatcher("/pages/list.jsp");		
		rd.forward(request,response);
		
		
		
	}
	
}
