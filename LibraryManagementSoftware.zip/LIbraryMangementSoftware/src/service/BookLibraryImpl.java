package service;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.mysql.jdbc.PreparedStatement;
import com.mysql.jdbc.ResultSet;
import connection.DbConnection;
import model.BookLibrary;

public class BookLibraryImpl implements BookLibraryInterface {

	Connection conn=null;
	PreparedStatement ps=null;

	@Override
	public void saveData(BookLibrary b) {
		// TODO Auto-generated method stub
		try {
			
			System.out.println("In impl bloc");
			conn = DbConnection.getDbConnection();		
			String sql="INSERT INTO booklibrary(bookname,title,author,publishername,copyright,edition,pages,isbn,copies,libraryname,shelfnum)"+"VALUES(?,?,?,?,?,?,?,?,?,?,?)";
			ps = (PreparedStatement) conn.prepareStatement(sql);
			ps.setString(1,b.getBookname());			
			ps.setString(2,b.getTitle());
			ps.setString(3,b.getAuthor());
			ps.setString(4,b.getPublishername());
			ps.setString(5,b.getCopyright());
			ps.setString(6,b.getEdition());		
			ps.setInt(7,b.getPages());
			ps.setDouble(8,b.getIsbn());
			ps.setInt(9,b.getCopies());		
			ps.setString(10,b.getLibraryname());	
			ps.setInt(11,b.getShelfnum());
			
			int i=ps.executeUpdate();
			System.out.println("Data inserted with "+i);
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (SQLException e) {
			e.printStackTrace();
		}
	}

	@Override
	public List<BookLibrary> getAllInfo() {
		//TODO Auto-generated method stub
		
		List<BookLibrary> list=new ArrayList<BookLibrary>();	
		try {
			
			conn=DbConnection.getDbConnection();
			String sql="SELECT * FROM booklibrary";
			
			PreparedStatement ps=(PreparedStatement) conn.prepareStatement(sql);
			ResultSet rs=(ResultSet) ps.executeQuery();
			while(rs.next()){
				
				BookLibrary bookLib=new BookLibrary();			
				bookLib.setId(rs.getInt("id"));		
				bookLib.setBookname(rs.getString("bookname"));
				bookLib.setTitle(rs.getString("title"));
				bookLib.setAuthor(rs.getString("author"));
				bookLib.setPublishername(rs.getString("publishername"));
				bookLib.setCopyright(rs.getString("copyright"));
				bookLib.setEdition(rs.getString("edition"));
				bookLib.setPages(rs.getInt("pages"));
				bookLib.setIsbn(rs.getDouble("isbn"));
				bookLib.setCopies(rs.getInt("copies"));
				bookLib.setLibraryname(rs.getString("libraryname"));
				bookLib.setShelfnum(rs.getInt("shelfnum"));			
				list.add(bookLib);
								
			}
					
		} catch (SQLException e) {

			e.printStackTrace();
					
		}
		
		 catch (ClassNotFoundException e) {

				e.printStackTrace();
						
			}
				
		return list;
	}

	
	
	
	@Override
	public BookLibrary getInfoById(int id) {
		// TODO Auto-generated method stub
		BookLibrary b=new BookLibrary();

		try {
			conn=DbConnection.getDbConnection();
			String sql="SELECT * FROM booklibrary WHERE id=?";
			PreparedStatement ps=(PreparedStatement) conn.prepareStatement(sql);
			
			ps.setInt(1,id);//used to take vAalue of row 1 
			ResultSet rs=(ResultSet) ps.executeQuery();

			while(rs.next()) 
			{
				b.setId(rs.getInt("id"));
				b.setBookname(rs.getString("bookname"));
				b.setTitle(rs.getString("title"));
				b.setAuthor(rs.getString("author"));
				b.setPublishername(rs.getString("publishername"));
				b.setCopyright(rs.getString("copyright"));
				b.setEdition(rs.getString("edition"));
				b.setPages(rs.getInt("pages"));
				b.setIsbn(rs.getDouble("isbn"));
				b.setCopies(rs.getInt("copies"));
				b.setLibraryname(rs.getString("libraryname"));
				b.setShelfnum(rs.getInt("shelfnum"));									
				
			}			
		}

		catch (ClassNotFoundException e)
		{
			
			e.printStackTrace();
		}
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
       	return b;

	
	}
	
	@Override
	public void editInfo(BookLibrary b) {
		// TODO Auto-generated method stub
		
		try {
			
			System.out.println("Edit Block ");
			conn=DbConnection.getDbConnection();
			//String sql="UPDATE booklibrary SET bookname=?,title=?,author=?,publishername=?,copyright=?,edition=?,pages=?,isbn=?,copies=?,libraryname=?,shelfnum=? where id=?";
			
			
			
			String sql = "UPDATE  booklibrary SET bookname=?,title=?,author=?,publishername=?,copyright=?,edition=?,pages=?,isbn=?,copies=?,libraryname=?,shelfnum=? where id=?";

			 ps=(PreparedStatement) conn.prepareStatement(sql);

			//ResultSet rs=(ResultSet) ps.executeQuery();
			
			ps.setString(1,b.getBookname());
			ps.setString(2,b.getTitle());
			ps.setString(3,b.getAuthor());
			ps.setString(4,b.getPublishername());
			ps.setString(5,b.getCopyright());
			ps.setString(6,b.getEdition());
			ps.setInt(7,b.getPages());
			ps.setDouble(8,b.getIsbn());
			ps.setInt(9,b.getCopies());
			ps.setString(10,b.getLibraryname());
			ps.setInt(11,b.getShelfnum());
			ps.setInt(12,b.getId());

			int i=ps.executeUpdate();
			System.out.println(i);

			System.out.println("Data updated with "+i);		
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
		catch (SQLException e) {
			e.printStackTrace();
		}
				
		
	}

	@Override
	public BookLibrary searchInfo(String bookname) {
		// TODO Auto-generated method stub
		
		//List<BookLibrary> list=new ArrayList<BookLibrary>();
		
		BookLibrary b=new BookLibrary();

		try {
			conn=DbConnection.getDbConnection();
			String sql="SELECT * FROM booklibrary WHERE bookname=?";
			PreparedStatement ps=(PreparedStatement) conn.prepareStatement(sql);
			ps.setString(1,bookname);
			ResultSet rs=(ResultSet) ps.executeQuery();
			
			while(rs.next()) {
						
				b.setId(rs.getInt("id"));
				b.setBookname(rs.getString("bookname"));
				b.setTitle(rs.getString("title"));
				b.setAuthor(rs.getString("author"));
				b.setPublishername(rs.getString("publishername"));
				b.setCopyright(rs.getString("copyright"));
				b.setEdition(rs.getString("edition"));
				b.setPages(rs.getInt("pages"));
				b.setIsbn(rs.getDouble("isbn"));
				b.setCopies(rs.getInt("copies"));
				b.setLibraryname(rs.getString("libraryname"));
				b.setShelfnum(rs.getInt("shelfnum"));
				//list.add(b);
									
			}
					
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return b;
		
	}	
	}

	
