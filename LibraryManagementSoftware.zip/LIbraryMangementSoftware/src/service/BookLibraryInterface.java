package service;

import java.util.List;
import model.BookLibrary;

 public interface BookLibraryInterface {

	public void saveData(BookLibrary b);
	public List<BookLibrary> getAllInfo();
	public BookLibrary getInfoById(int id);
	public void editInfo(BookLibrary b);
	public BookLibrary searchInfo(String bookname);
	
	
}
