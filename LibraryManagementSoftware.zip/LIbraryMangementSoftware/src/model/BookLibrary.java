package model;

public class BookLibrary {
	
	
	int id;
	String bookname;
	String title;
	String author;	
	String publishername;	
	String copyright;
	String edition;
	int pages;
	Double isbn;	
	int copies;
	String libraryname;
	int shelfnum;
	
	public BookLibrary(){
		
		
		
	}
	public BookLibrary(String bookname,String title,String author,String publishername,String copyright,String edition,int pages,Double isbn,int copies,String libraryname,int shelfnum)
	{
		
		this.id=id;
		this.bookname=bookname;
		this.title=title;
		this.author=author;
		this.publishername=publishername;
		this.copyright=copyright;
		this.edition=edition;
		this.pages=pages;
		this.isbn=isbn;
		this.copies=copies;
		
		this.libraryname=libraryname;
		
		this.shelfnum=shelfnum;
		
		
		
	}
	
	public int getId() {
		return id;	
	}
	public String getBookname() {
		return bookname;
	}
	public String getTitle() {
		return title;
	}
	public String getAuthor() {
		return author;
	}
	public String getPublishername() {
		return publishername;
	}
	public String getCopyright() {
		return copyright;
	}
	public String getEdition() {
		return edition;
	}
	public int getPages() {
		return pages;
	}
	public Double getIsbn() {
		return isbn;
	}
	public int getCopies() {
		return copies;
	}
	public String getLibraryname() {
		return libraryname;
	}
	public int getShelfnum() {
		return shelfnum;
	}
	public void setId(int id) {
		this.id = id;
	}
	public void setBookname(String bookname) {
		this.bookname = bookname;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public void setPublishername(String publishername) {
		this.publishername = publishername;
	}
	public void setCopyright(String copyright) {
		this.copyright = copyright;
	}
	public void setEdition(String edition) {
		this.edition = edition;
	}
	public void setPages(Integer pages) {
		this.pages = pages;
	}
	public void setIsbn(Double isbn) {
		this.isbn = isbn;
	}
	public void setCopies(Integer copies) {
		this.copies = copies;
	}
	public void setLibraryname(String libraryname) {
		this.libraryname = libraryname;
	}
	public void setShelfnum(Integer shelfnum) {
		this.shelfnum = shelfnum;
	}
	@Override
	public String toString() {
		return "BookLibrary [id=" + id + ", bookname=" + bookname + ", title=" + title + ", author=" + author
				+ ", publishername=" + publishername + ", copyright=" + copyright + ", edition=" + edition + ", pages="
				+ pages + ", isbn=" + isbn + ", copies=" + copies + ", libraryname=" + libraryname + ", shelfnum="
				+ shelfnum + "]";
	}
	
	
	
	
	
	
	
	
	
	
	
	
}